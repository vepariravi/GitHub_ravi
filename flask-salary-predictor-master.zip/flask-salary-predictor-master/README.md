# flask-salary-predictor
This is project predicts the salary of the employee based on the experience.

# Model
model.py trains and saves the model to the disk.

# Server
server.py contains all the requiered for flask and to manage APIs.

# Request
request.py contains the python code to process POST request to server.
